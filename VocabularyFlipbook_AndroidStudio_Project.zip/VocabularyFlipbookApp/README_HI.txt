VOCABULARY FLIPBOOK - ANDROID APP SOURCE

Features:
- Native Android app (not a browser tab)
- Import a PDF once; it is copied into the app's private storage
- Works offline after the PDF has been imported
- Touch/drag page turning, previous/next, zoom and fit controls
- No network permission or online JavaScript libraries

IMPORTANT:
This is the Android Studio project source, not a prebuilt APK. This environment has no Android SDK/Gradle installation, so I could not compile and test an APK here.

Build an APK:
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Android Studio > Open > choose the VocabularyFlipbook folder.
4. Allow Android Studio to sync Gradle and install the Android SDK it requests.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Copy app/build/outputs/apk/debug/app-debug.apk to your phone and install it. If prompted, allow installing apps from that source.
7. Open Vocabulary Flipbook and tap Open PDF. Choose Vocabulary_Pages_Alphabetical_A-Z.pdf.
   The app copies it to private phone storage, then the PDF remains available offline.

The source PDF is not bundled into the app because it is large (about 124 MB). Import it once from the phone's Downloads folder or another location.
