package com.example.vocabularyflipbook

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class FlipBookView(context: Context, private val getRenderer: () -> PdfRenderer?) : View(context) {
    var currentPage = 0; private set
    private var count = 0
    private var zoom = 1f
    private var pageBitmap: Bitmap? = null
    private var nextBitmap: Bitmap? = null
    private var drag = 0f
    private var turning = false
    private var startX = 0f
    private var startY = 0f
    private val paper = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33000000 }
    private val camera = Camera()
    private val matrix = Matrix()
    private val bg = Paint().apply { color = Color.rgb(226,220,207) }

    fun setPageCount(n: Int) { count=n; currentPage=0; zoom=1f; renderCurrent(); invalidate() }
    fun changeZoom(delta: Float) { zoom=(zoom+delta).coerceIn(0.7f,2.8f); invalidate() }
    fun resetZoom() { zoom=1f; invalidate() }
    fun turn(direction: Int) { if(count==0||turning)return; val target=(currentPage+direction).coerceIn(0,count-1); if(target==currentPage)return; animateTurn(direction,target) }

    private fun renderBitmap(index: Int): Bitmap? {
        val renderer=getRenderer() ?: return null
        if(index !in 0 until renderer.pageCount) return null
        val page=renderer.openPage(index)
        val targetW=max(600, min(1800, width.coerceAtLeast(600)*2))
        val scale=targetW.toFloat()/page.width
        val w=(page.width*scale).toInt().coerceAtLeast(1); val h=(page.height*scale).toInt().coerceAtLeast(1)
        val b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
        b.eraseColor(Color.WHITE)
        page.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()
        return b
    }
    private fun renderCurrent() { pageBitmap?.recycle(); nextBitmap?.recycle(); pageBitmap=renderBitmap(currentPage); nextBitmap=null }
    private fun animateTurn(direction:Int,target:Int) {
        turning=true
        nextBitmap?.recycle(); nextBitmap=renderBitmap(target)
        val from=drag; val to=if(direction>0) -width.toFloat() else width.toFloat()
        ValueAnimator.ofFloat(from,to).apply {
            duration=420
            addUpdateListener { drag=it.animatedValue as Float; invalidate() }
            doOnEnd { currentPage=target; pageBitmap?.recycle(); pageBitmap=nextBitmap; nextBitmap=null; drag=0f; turning=false; invalidate() }
            start()
        }
    }
    private fun ValueAnimator.doOnEnd(block: () -> Unit) { addListener(object: android.animation.AnimatorListenerAdapter(){ override fun onAnimationEnd(animation: android.animation.Animator){ block() } }) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas); canvas.drawColor(Color.rgb(242,239,231))
        val b=pageBitmap ?: run {
            val p=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(50,60,75); textAlign=Paint.Align.CENTER; textSize=17f }
            canvas.drawText("Open your vocabulary PDF",width/2f,height/2f,p); canvas.drawText("to start the flipbook",width/2f,height/2f+28f,p); return
        }
        val scale=min((width*0.90f)/b.width,(height*0.92f)/b.height)*zoom
        val w=b.width*scale; val h=b.height*scale
        val left=(width-w)/2f; val top=(height-h)/2f
        val rect=RectF(left,top,left+w,top+h)
        canvas.drawRoundRect(RectF(rect.left+5,rect.top+7,rect.right+5,rect.bottom+7),3f,3f,shadow)
        canvas.drawRoundRect(rect,3f,3f,bg)
        if(drag==0f || nextBitmap==null) canvas.drawBitmap(b,null,rect,paper) else {
            val under=nextBitmap!!
            canvas.drawBitmap(under,null,rect,paper)
            val progress=(abs(drag)/width.coerceAtLeast(1)).coerceIn(0f,1f)
            val hinge=if(drag<0) rect.right else rect.left
            val save=canvas.save()
            val clip=if(drag<0) RectF(rect.left,rect.top,hinge+drag,rect.bottom) else RectF(hinge+drag,rect.top,rect.right,rect.bottom)
            canvas.clipRect(clip)
            canvas.drawBitmap(b,null,rect,paper)
            canvas.restoreToCount(save)
            // Curved-paper illusion: narrow shaded fold follows the moving edge.
            val edge=if(drag<0) rect.right+drag else rect.left+drag
            val fold=Paint(Paint.ANTI_ALIAS_FLAG).apply { shader=LinearGradient(edge-18,0f,edge+18,0f,intArrayOf(0x00000000,0x44000000,0x00000000),null,Shader.TileMode.CLAMP) }
            canvas.drawRect(edge-18,rect.top,edge+18,rect.bottom,fold)
        }
        // Subtle binding and paper edge
        val bind=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=0x18000000 }
        canvas.drawRect(rect.left,rect.top,rect.left+3,rect.bottom,bind)
        canvas.drawRect(rect.right-2,rect.top,rect.right,rect.bottom,bind)
        if(zoom>1f) { val p=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=0x99000000; textSize=12f; textAlign=Paint.Align.CENTER }; canvas.drawText("Zoom ${"%.0f".format(zoom*100)}%",width/2f,height-12f,p) }
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when(event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { startX=event.x; startY=event.y; return true }
            MotionEvent.ACTION_MOVE -> { if(!turning && abs(event.x-startX)>abs(event.y-startY)*1.1f) { drag=(event.x-startX).coerceIn(-width.toFloat(),width.toFloat()); invalidate() }; return true }
            MotionEvent.ACTION_UP -> {
                val dx=event.x-startX; val dy=event.y-startY
                if(abs(dx)>45 && abs(dx)>abs(dy)*1.1f) turn(if(dx<0) 1 else -1) else { drag=0f; invalidate() }
                performClick(); return true
            }
            MotionEvent.ACTION_CANCEL -> { drag=0f; invalidate(); return true }
        }; return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
