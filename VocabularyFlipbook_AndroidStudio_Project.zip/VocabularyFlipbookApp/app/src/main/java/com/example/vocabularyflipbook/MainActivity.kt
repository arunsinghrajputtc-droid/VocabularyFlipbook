package com.example.vocabularyflipbook

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var book: FlipBookView
    private lateinit var counter: TextView
    private var renderer: PdfRenderer? = null
    private var pfd: ParcelFileDescriptor? = null
    private val pickPdf = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(20,43,73)
        window.navigationBarColor = Color.rgb(20,43,73)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(242,239,231)) }
        val header = TextView(this).apply {
            text = "VOCABULARY FLIPBOOK  A–Z\nHand-drag pages • Offline reader"
            textSize = 17f; setTextColor(Color.WHITE); setPadding(18,18,12,18); setBackgroundColor(Color.rgb(20,43,73))
        }
        root.addView(header)
        book = FlipBookView(this) { renderer }
        root.addView(book, LinearLayout.LayoutParams(-1, 0, 1f))
        counter = TextView(this).apply { text = "Choose your vocabulary PDF to begin"; gravity = Gravity.CENTER; setTextColor(Color.rgb(50,60,75)); setPadding(8,10,8,10) }
        root.addView(counter)
        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        row1.addView(button("📂 Open PDF") { openPicker() }, weight())
        row1.addView(button("‹ Previous") { book.turn(-1); updateCounter() }, weight())
        row1.addView(button("Next ›") { book.turn(1); updateCounter() }, weight())
        root.addView(row1)
        val row2 = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        row2.addView(button("− Zoom") { book.changeZoom(-0.15f) }, weight())
        row2.addView(button("+ Zoom") { book.changeZoom(0.15f) }, weight())
        row2.addView(button("Fit page") { book.resetZoom() }, weight())
        root.addView(row2)
        val footer = TextView(this).apply { text = "Tip: drag from the page edge to turn it. Imported PDF is saved on this phone for offline use."; textSize=11f; gravity=Gravity.CENTER; setTextColor(Color.DKGRAY); setPadding(12,8,12,12) }
        root.addView(footer)
        setContentView(root)
        val saved = File(filesDir, "vocabulary.pdf")
        if (saved.exists()) runCatching { loadPdf(saved) }
    }
    private fun weight() = LinearLayout.LayoutParams(0, 48, 1f).apply { setMargins(3,3,3,3) }
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text=label; textSize=12f; isAllCaps=false; setOnClickListener { action() } }
    private fun openPicker() { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/pdf" }, pickPdf) }
    @Deprecated("Legacy activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==pickPdf && resultCode==RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                val out = File(filesDir,"vocabulary.pdf")
                contentResolver.openInputStream(uri)!!.use { input -> FileOutputStream(out).use { output -> input.copyTo(output) } }
                loadPdf(out)
                Toast.makeText(this,"PDF saved for offline use",Toast.LENGTH_LONG).show()
            } catch(e: Exception) { Toast.makeText(this,"Could not open PDF: ${e.message}",Toast.LENGTH_LONG).show() }
        }
    }
    private fun loadPdf(file: File) {
        renderer?.close(); pfd?.close()
        pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        renderer = PdfRenderer(pfd!!)
        book.setPageCount(renderer!!.pageCount)
        updateCounter()
    }
    private fun updateCounter() { counter.text = if(renderer==null) "Choose your vocabulary PDF to begin" else "Page ${book.currentPage+1} of ${renderer!!.pageCount}" }
    override fun onDestroy() { renderer?.close(); pfd?.close(); super.onDestroy() }
}
